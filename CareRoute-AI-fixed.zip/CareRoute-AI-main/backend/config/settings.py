"""
settings.py - Configuration settings for CareRoute AI
"""
import os

class Config:
    PROJECT_NAME = "CareRoute AI"
    VERSION = "2.0.0"
    DEBUG = True
    PORT = int(os.getenv("PORT", 5000))
    HOST = "0.0.0.0"
    
    # Default GPS coordinates (Metro Central)
    DEFAULT_LATITUDE = 13.0827
    DEFAULT_LONGITUDE = 80.2707
    DEFAULT_CITY = "Chennai"
    
    # Triage Urgency Thresholds (1-5 scale)
    CRITICAL_URGENCY_THRESHOLD = 4  # >= 4 triggers EmergencyAgent
    ROUTINE_URGENCY_THRESHOLD = 2   # <= 2 triggers standard pharmacy/clinic
    
    # Speed profiles (km/h) for routing ETA calculation
    AMBULANCE_SPEED_KMH = 65.0
    CAR_SPEED_KMH = 35.0
