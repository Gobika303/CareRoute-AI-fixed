"""
schemas.py - Data schemas for CareRoute AI
"""
from dataclasses import dataclass, asdict, field
from typing import List, Optional, Dict, Any

@dataclass
class UserQuery:
    query: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    user_name: str = "Anonymous Patient"
    blood_group: str = "O+"
    medical_notes: str = "None"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class IntentResult:
    intent_category: str  # 'CRITICAL_EMERGENCY', 'URGENT_CARE', 'PHARMACY_REQUEST', 'ROUTINE_CONSULT'
    urgency_level: int    # 1 to 5
    is_critical: bool
    specialty_needed: str
    identified_symptoms: List[str]
    triage_summary: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class Hospital:
    id: str
    name: str
    type: str  # 'Multispeciality Hospital', 'Trauma Center', 'Clinic'
    latitude: float
    longitude: float
    distance_km: float
    eta_mins: int
    trauma_level: str
    icu_beds_available: int
    burn_unit: bool
    phone: str
    address: str
    rating: float
    specialties: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class Pharmacy:
    id: str
    name: str
    latitude: float
    longitude: float
    distance_km: float
    eta_mins: int
    is_24_hours: bool
    phone: str
    address: str
    rating: float
    emergency_stock: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class RouteDetails:
    origin_name: str
    destination_name: str
    distance_km: float
    eta_mins: int
    driving_instructions: List[str]
    coordinates: List[List[float]]  # [[lat, lng], ...]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class EmergencyDispatch:
    dispatch_id: str
    target_hospital: Hospital
    urgency_code: str
    first_aid_instructions: List[str]
    patient_triage: Dict[str, Any]
    timestamp: str
    ambulance_status: str

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["target_hospital"] = self.target_hospital.to_dict()
        return d

@dataclass
class CareRecommendation:
    query: str
    intent: IntentResult
    primary_recommendation: Optional[Hospital]
    alternative_hospitals: List[Hospital]
    nearby_pharmacies: List[Pharmacy]
    route_details: Optional[RouteDetails]
    emergency_dispatch: Optional[EmergencyDispatch]
    agent_reasoning_log: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "query": self.query,
            "intent": self.intent.to_dict(),
            "primary_recommendation": self.primary_recommendation.to_dict() if self.primary_recommendation else None,
            "alternative_hospitals": [h.to_dict() for h in self.alternative_hospitals],
            "nearby_pharmacies": [p.to_dict() for p in self.nearby_pharmacies],
            "route_details": self.route_details.to_dict() if self.route_details else None,
            "emergency_dispatch": self.emergency_dispatch.to_dict() if self.emergency_dispatch else None,
            "agent_reasoning_log": self.agent_reasoning_log
        }
