"""FastAPI backend for CareRoute AI.

This project uses local demo facility data and simulated dispatch/routing.
It does not contact ambulance services or verify real-time hospital capacity.
"""
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from agents.care_graph import process_query
from agents.emergency_agent import EmergencyAgent
from agents.intent_agent import IntentAgent
from models.schemas import UserQuery
from services.hospital_service import HospitalService
from services.pharmacy_service import PharmacyService
from services.route_service import RouteService

app = FastAPI(title="CareRoute AI - Agentic Backend", version="2.0.1")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

hospital_service = HospitalService()
pharmacy_service = PharmacyService()
route_service = RouteService()
intent_agent = IntentAgent()
emergency_agent = EmergencyAgent()


class ChatRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=2000)
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)
    user_name: str = "Anonymous Patient"
    blood_group: str = "Unknown"
    medical_notes: str = "None"


class RouteRequest(BaseModel):
    origin_lat: float = Field(..., ge=-90, le=90)
    origin_lng: float = Field(..., ge=-180, le=180)
    dest_lat: float = Field(..., ge=-90, le=90)
    dest_lng: float = Field(..., ge=-180, le=180)
    dest_name: str = "Destination Medical Facility"
    origin_name: str = "Current Location"


class EmergencyRequest(BaseModel):
    hospital_id: str = "HOSP_01"
    user_name: str = "Citizen"
    medical_notes: str = "Critical"


@app.get("/")
def home():
    return {
        "message": "CareRoute Agentic AI Backend Running",
        "status": "ok",
        "api_docs": "/docs",
        "note": "Demo only: hospital, pharmacy, routing and dispatch data are simulated."
    }


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/chat")
def chat(data: ChatRequest):
    query = UserQuery(
        query=data.query.strip(),
        latitude=data.latitude,
        longitude=data.longitude,
        user_name=data.user_name,
        blood_group=data.blood_group,
        medical_notes=data.medical_notes,
    )
    if not query.query:
        raise HTTPException(status_code=422, detail="Please enter symptoms or a medical need.")
    try:
        recommendation = process_query(query)
        return recommendation.to_dict()
    except Exception as exc:
        # Keep the API error visible in the server log while returning a useful message.
        print(f"Care graph error: {type(exc).__name__}: {exc}")
        raise HTTPException(status_code=500, detail="Care analysis failed. Check the backend terminal for details.") from exc


@app.get("/api/hospitals")
def hospitals(
    lat: Optional[float] = Query(default=None, ge=-90, le=90),
    lng: Optional[float] = Query(default=None, ge=-180, le=180),
    specialty: Optional[str] = None,
):
    items = (
        hospital_service.filter_by_specialty(specialty, lat, lng)
        if specialty and lat is not None and lng is not None
        else hospital_service.get_all_hospitals(lat, lng)
    )
    return {"hospitals": [item.to_dict() for item in items]}


@app.get("/api/pharmacies")
def pharmacies(
    lat: Optional[float] = Query(default=None, ge=-90, le=90),
    lng: Optional[float] = Query(default=None, ge=-180, le=180),
    medicine: Optional[str] = None,
):
    if medicine and lat is not None and lng is not None:
        items = pharmacy_service.search_by_medicine(medicine, lat, lng)
    else:
        items = pharmacy_service.get_nearby_pharmacies(lat, lng)
    return {"pharmacies": [item.to_dict() for item in items]}


@app.post("/api/route")
def route(data: RouteRequest):
    details = route_service.calculate_route(
        data.origin_lat,
        data.origin_lng,
        data.dest_lat,
        data.dest_lng,
        data.origin_name,
        data.dest_name,
    )
    return details.to_dict()


@app.post("/api/emergency/dispatch")
def emergency_dispatch(data: EmergencyRequest):
    hospital = hospital_service.get_hospital_by_id(data.hospital_id)
    if hospital is None:
        hospital = hospital_service.get_all_hospitals()[0]
    query = UserQuery(
        query=data.medical_notes,
        user_name=data.user_name,
        medical_notes=data.medical_notes,
    )
    intent = intent_agent.analyze_intent(data.medical_notes or "emergency")
    # This creates a local demo dispatch record only; it does not alert an ambulance.
    return emergency_agent.process_emergency(query, intent, hospital).to_dict()


# Backwards-compatible endpoint used by early project versions.
class LegacySymptomRequest(BaseModel):
    symptoms: str = Field(..., min_length=1, max_length=2000)


@app.post("/analyze")
def analyze(data: LegacySymptomRequest):
    result = process_query(UserQuery(query=data.symptoms))
    return {"status": "success", **result.to_dict()}
