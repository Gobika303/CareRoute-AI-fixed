"""
coordinator_agent.py - Master Orchestrator Agent for CareRoute AI
"""
from typing import Dict, Any, List
from models.schemas import (
    UserQuery,
    CareRecommendation,
    RouteDetails,
    EmergencyDispatch
)
from agents.intent_agent import IntentAgent
from agents.emergency_agent import EmergencyAgent
from agents.recommendation_agent import RecommendationAgent
from tools.maps_tool import MapsTool
from tools.places_tool import PlacesTool
from tools.location_tool import LocationTool

class CoordinatorAgent:
    def __init__(
        self,
        intent_agent: IntentAgent,
        emergency_agent: EmergencyAgent,
        recommendation_agent: RecommendationAgent,
        maps_tool: MapsTool,
        places_tool: PlacesTool,
        location_tool: LocationTool
    ):
        self.intent_agent = intent_agent
        self.emergency_agent = emergency_agent
        self.recommendation_agent = recommendation_agent
        self.maps_tool = maps_tool
        self.places_tool = places_tool
        self.location_tool = location_tool

    def process_query(self, user_query: UserQuery) -> CareRecommendation:
        logs: List[str] = []
        logs.append(f"[CoordinatorAgent] Ingested patient inquiry: '{user_query.query}'")

        # 1. Resolve Location Coordinates
        lat, lng, loc_name = self.location_tool.resolve_location(
            user_query.query, user_query.latitude, user_query.longitude
        )
        logs.append(f"[LocationTool] Geocoded location: {loc_name} ({lat}, {lng})")

        # 2. Analyze Intent & Medical Urgency
        intent = self.intent_agent.analyze_intent(user_query.query)
        logs.append(f"[IntentAgent] {intent.triage_summary}")

        # 3. Retrieve Candidate Places
        candidates = self.places_tool.find_nearby_hospitals(lat, lng, intent.specialty_needed)
        nearby_pharmacies = self.places_tool.find_nearby_pharmacies(lat, lng)

        emergency_dispatch: EmergencyDispatch = None
        primary_hosp = None
        alternatives = []

        # 4. Handle Critical Emergency vs. Routine Care
        if intent.is_critical:
            logs.append("[CoordinatorAgent] Urgent critical condition detected! Engaging EmergencyAgent...")
            requires_burn = "burn" in intent.specialty_needed.lower()
            # Select best trauma center
            primary_hosp = self.places_tool.hospital_service.find_best_trauma_center(lat, lng, requires_burn)
            alternatives = [h for h in candidates if h.id != primary_hosp.id][:3]

            emergency_dispatch = self.emergency_agent.process_emergency(
                user_query, intent, primary_hosp
            )
            logs.append(
                f"[EmergencyAgent] Code Red Golden-Hour Pre-Alert dispatched to {primary_hosp.name} (ETA: {primary_hosp.eta_mins}m)."
            )
        else:
            logs.append("[CoordinatorAgent] Invoking RecommendationAgent for multi-criteria ranking...")
            primary_hosp, alternatives, rec_logs = self.recommendation_agent.rank_hospitals(
                candidates, intent
            )
            logs.extend([f"[RecommendationAgent] {l}" for l in rec_logs])

        # 5. Generate Route to Target Facility
        route: RouteDetails = None
        if primary_hosp:
            route = self.maps_tool.get_route(
                lat, lng, primary_hosp.latitude, primary_hosp.longitude,
                loc_name, primary_hosp.name
            )
            logs.append(f"[MapsTool] Calculated optimal route: {route.distance_km} km, ~{route.eta_mins} mins driving time.")

        return CareRecommendation(
            query=user_query.query,
            intent=intent,
            primary_recommendation=primary_hosp,
            alternative_hospitals=alternatives,
            nearby_pharmacies=nearby_pharmacies,
            route_details=route,
            emergency_dispatch=emergency_dispatch,
            agent_reasoning_log=logs
        )
