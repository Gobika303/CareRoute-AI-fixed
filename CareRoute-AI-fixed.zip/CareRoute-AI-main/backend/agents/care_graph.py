"""LangGraph workflow for CareRoute AI's deterministic agent pipeline."""
from typing import Any, Dict, List, Optional, TypedDict

from langgraph.graph import END, START, StateGraph

from agents.emergency_agent import EmergencyAgent
from agents.intent_agent import IntentAgent
from agents.recommendation_agent import RecommendationAgent
from models.schemas import CareRecommendation, EmergencyDispatch, IntentResult, RouteDetails, UserQuery
from services.hospital_service import HospitalService
from services.pharmacy_service import PharmacyService
from services.route_service import RouteService
from tools.location_tool import LocationTool
from tools.maps_tool import MapsTool
from tools.places_tool import PlacesTool


class CareState(TypedDict, total=False):
    user_query: UserQuery
    logs: List[str]
    latitude: float
    longitude: float
    location_name: str
    intent: IntentResult
    candidates: list
    pharmacies: list
    primary_hospital: Any
    alternatives: list
    emergency_dispatch: Optional[EmergencyDispatch]
    route: Optional[RouteDetails]
    recommendation: CareRecommendation


def _build_tools() -> Dict[str, Any]:
    hospital_service = HospitalService()
    pharmacy_service = PharmacyService()
    return {
        "location": LocationTool(),
        "places": PlacesTool(hospital_service, pharmacy_service),
        "maps": MapsTool(RouteService()),
    }


def build_care_graph():
    tools = _build_tools()
    intent_agent = IntentAgent()
    emergency_agent = EmergencyAgent()
    recommendation_agent = RecommendationAgent()

    def resolve_location(state: CareState) -> Dict[str, Any]:
        query = state["user_query"]
        lat, lng, name = tools["location"].resolve_location(query.query, query.latitude, query.longitude)
        return {"latitude": lat, "longitude": lng, "location_name": name, "logs": [f"[LocationTool] Geocoded location: {name} ({lat}, {lng})"]}

    def analyze_intent(state: CareState) -> Dict[str, Any]:
        intent = intent_agent.analyze_intent(state["user_query"].query)
        return {"intent": intent, "logs": [f"[IntentAgent] {intent.triage_summary}"]}

    def retrieve_places(state: CareState) -> Dict[str, Any]:
        places = tools["places"]
        lat, lng = state["latitude"], state["longitude"]
        return {
            "candidates": places.find_nearby_hospitals(lat, lng, state["intent"].specialty_needed),
            "pharmacies": places.find_nearby_pharmacies(lat, lng),
            "logs": ["[PlacesTool] Retrieved nearby hospitals and pharmacies."],
        }

    def choose_path(state: CareState) -> str:
        return "emergency" if state["intent"].is_critical else "recommendation"

    def handle_emergency(state: CareState) -> Dict[str, Any]:
        intent = state["intent"]
        hospital = tools["places"].hospital_service.find_best_trauma_center(
            state["latitude"], state["longitude"], "burn" in intent.specialty_needed.lower()
        )
        dispatch = emergency_agent.process_emergency(state["user_query"], intent, hospital)
        return {
            "primary_hospital": hospital,
            "alternatives": [h for h in state["candidates"] if h.id != hospital.id][:3],
            "emergency_dispatch": dispatch,
            "logs": ["[CoordinatorAgent] Critical condition detected; engaging EmergencyAgent.", f"[EmergencyAgent] Code Red pre-alert dispatched to {hospital.name}."]
        }

    def handle_recommendation(state: CareState) -> Dict[str, Any]:
        primary, alternatives, recommendation_logs = recommendation_agent.rank_hospitals(state["candidates"], state["intent"])
        return {
            "primary_hospital": primary,
            "alternatives": alternatives,
            "logs": ["[CoordinatorAgent] Invoking RecommendationAgent.", *[f"[RecommendationAgent] {log}" for log in recommendation_logs]],
        }

    def calculate_route(state: CareState) -> Dict[str, Any]:
        hospital = state.get("primary_hospital")
        if not hospital:
            return {"route": None}
        route = tools["maps"].get_route(state["latitude"], state["longitude"], hospital.latitude, hospital.longitude, state["location_name"], hospital.name)
        return {"route": route, "logs": [f"[MapsTool] Calculated route: {route.distance_km} km, ~{route.eta_mins} mins."]}

    def finalize(state: CareState) -> Dict[str, Any]:
        return {"recommendation": CareRecommendation(
            query=state["user_query"].query,
            intent=state["intent"],
            primary_recommendation=state.get("primary_hospital"),
            alternative_hospitals=state.get("alternatives", []),
            nearby_pharmacies=state.get("pharmacies", []),
            route_details=state.get("route"),
            emergency_dispatch=state.get("emergency_dispatch"),
            agent_reasoning_log=[f"[CoordinatorAgent] Ingested patient inquiry: '{state['user_query'].query}'", *state.get("logs", [])],
        )}

    graph = StateGraph(CareState)
    for name, node in {
        "resolve_location": resolve_location,
        "analyze_intent": analyze_intent,
        "retrieve_places": retrieve_places,
        "handle_emergency": handle_emergency,
        "handle_recommendation": handle_recommendation,
        "calculate_route": calculate_route,
        "finalize": finalize,
    }.items():
        graph.add_node(name, node)
    graph.add_edge(START, "resolve_location")
    graph.add_edge("resolve_location", "analyze_intent")
    graph.add_edge("analyze_intent", "retrieve_places")
    graph.add_conditional_edges("retrieve_places", choose_path, {"emergency": "handle_emergency", "recommendation": "handle_recommendation"})
    graph.add_edge("handle_emergency", "calculate_route")
    graph.add_edge("handle_recommendation", "calculate_route")
    graph.add_edge("calculate_route", "finalize")
    graph.add_edge("finalize", END)
    return graph.compile()


care_graph = build_care_graph()


def process_query(user_query: UserQuery) -> CareRecommendation:
    return care_graph.invoke({"user_query": user_query, "logs": []})["recommendation"]