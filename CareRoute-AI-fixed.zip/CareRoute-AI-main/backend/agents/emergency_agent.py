"""
emergency_agent.py - Critical emergency triage and ambulance dispatch coordinator
"""
import time
from typing import List, Dict, Any
from models.schemas import Hospital, EmergencyDispatch, UserQuery, IntentResult

class EmergencyAgent:
    FIRST_AID_GUIDELINES: Dict[str, List[str]] = {
        "Cardiology": [
            "Keep the patient in a comfortable seated position, slightly inclined.",
            "Loosen tight clothing around neck and chest to ease breathing.",
            "If prescribed nitroglycerin or aspirin (325mg) is available, administer immediately.",
            "Do NOT let the patient walk or exert physical effort.",
            "Be prepared to begin CPR (100-120 chest compressions per minute) if responsiveness ceases."
        ],
        "Trauma & Emergency": [
            "Apply direct continuous pressure to bleeding wounds with sterile cloth or gauze.",
            "Do NOT remove deeply embedded objects; stabilize them with bulky dressing.",
            "Keep the patient calm, warm, and lying flat with legs elevated unless head injury is suspected.",
            "Avoid giving liquids or food if emergency surgery might be needed."
        ],
        "Burn Care": [
            "Immediately cool the burn with cool (not ice-cold) running water for 15-20 minutes.",
            "Do NOT apply butter, oil, or ice packs directly to burns.",
            "Cover loosely with a clean, dry, non-stick plastic wrap or sterile dressing.",
            "Protect from hypothermia once burned area is cooled."
        ],
        "Pulmonology": [
            "Help the patient sit upright; leaning forward slightly helps expand the lungs.",
            "Administer quick-relief bronchodilator inhaler (2 to 4 puffs with spacer if available).",
            "Maintain calm environment; encourage slow, pursed-lip breathing."
        ]
    }

    DEFAULT_FIRST_AID = [
        "Stay calm and ensure the immediate environment is safe for the patient.",
        "Check breathing, airway, and pulse periodically.",
        "Do not move patient if neck or spinal injury is suspected unless immediate danger exists.",
        "Keep emergency dispatch line open until first responders arrive."
    ]

    def process_emergency(
        self,
        query: UserQuery,
        intent: IntentResult,
        target_hospital: Hospital
    ) -> EmergencyDispatch:
        specialty = intent.specialty_needed
        first_aid = self.FIRST_AID_GUIDELINES.get(specialty, self.DEFAULT_FIRST_AID)

        dispatch_id = f"CARE-SOS-{int(time.time())}"
        patient_triage_data = {
            "patient_name": query.user_name,
            "blood_group": query.blood_group,
            "medical_flags": query.medical_notes,
            "symptoms_reported": intent.identified_symptoms,
            "urgency_score": intent.urgency_level,
            "golden_hour_eta_minutes": target_hospital.eta_mins,
            "ambulance_unit_dispatched": "Advanced Life Support (ALS) Unit #4"
        }

        return EmergencyDispatch(
            dispatch_id=dispatch_id,
            target_hospital=target_hospital,
            urgency_code="CODE_RED_CRITICAL",
            first_aid_instructions=first_aid,
            patient_triage=patient_triage_data,
            timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
            ambulance_status="EN_ROUTE_WITH_PRE_ALERT"
        )
