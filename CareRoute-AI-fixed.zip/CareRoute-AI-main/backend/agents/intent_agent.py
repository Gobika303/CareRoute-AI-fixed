"""
intent_agent.py - Clinical intent analysis and symptom triage agent
"""
import re
from typing import List, Dict, Any, Tuple
from models.schemas import IntentResult

class IntentAgent:
    CRITICAL_KEYWORDS = {
        "chest pain": ("Cardiology", 5),
        "heart attack": ("Cardiology", 5),
        "stroke": ("Neurology", 5),
        "paralysis": ("Neurology", 5),
        "unconscious": ("Trauma & Emergency", 5),
        "not breathing": ("Pulmonology", 5),
        "heavy bleeding": ("Trauma & Emergency", 5),
        "burns": ("Burn Care", 4),
        "fracture": ("Orthopedics", 4),
        "broken bone": ("Orthopedics", 4),
        "poison": ("Toxicology", 5),
        "severe asthma": ("Pulmonology", 4),
        "difficulty breathing": ("Pulmonology", 4),
        "head injury": ("Neurology", 4),
        "accident": ("Trauma & Emergency", 5)
    }

    PEDIATRIC_KEYWORDS = ["child", "baby", "infant", "kid", "toddler", "pediatric"]
    PHARMACY_KEYWORDS = ["medicine", "tablet", "syrup", "pharmacy", "inhaler", "insulin", "dressing", "oxygen canister", "bandages"]

    def analyze_intent(self, text: str) -> IntentResult:
        text_lower = text.lower()
        matched_symptoms: List[str] = []
        highest_urgency = 1
        specialty = "General Medicine"
        category = "ROUTINE_CONSULT"

        # 1. Check Critical Keywords
        for kw, (spec, urg) in self.CRITICAL_KEYWORDS.items():
            if re.search(r"\b" + re.escape(kw) + r"\b", text_lower) or kw in text_lower:
                matched_symptoms.append(kw)
                if urg > highest_urgency:
                    highest_urgency = urg
                    specialty = spec

        # 2. Check Pediatrics
        if any(p in text_lower for p in self.PEDIATRIC_KEYWORDS):
            matched_symptoms.append("pediatric patient")
            if specialty == "General Medicine":
                specialty = "Pediatrics"
            highest_urgency = max(highest_urgency, 3)

        # 3. Check Pharmacy Needs
        if any(ph in text_lower for ph in self.PHARMACY_KEYWORDS) and highest_urgency <= 2:
            matched_symptoms.append("medical supplies/drugs")
            category = "PHARMACY_REQUEST"
            specialty = "Pharmacy Supplies"

        # 4. Determine Category
        if highest_urgency >= 4:
            category = "CRITICAL_EMERGENCY"
        elif highest_urgency == 3:
            category = "URGENT_CARE"
        elif category != "PHARMACY_REQUEST":
            category = "ROUTINE_CONSULT"

        if not matched_symptoms:
            matched_symptoms = ["general health concern"]

        triage_summary = (
            f"Triage Level {highest_urgency}/5 ({category.replace('_', ' ')}). "
            f"Specialty Required: {specialty}."
        )

        return IntentResult(
            intent_category=category,
            urgency_level=highest_urgency,
            is_critical=(highest_urgency >= 4),
            specialty_needed=specialty,
            identified_symptoms=matched_symptoms,
            triage_summary=triage_summary
        )
