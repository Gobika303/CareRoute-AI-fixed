from langgraph.graph import StateGraph, END
from typing import TypedDict


class CareState(TypedDict):
    symptoms: str
    urgency: str
    recommendation: str


def symptom_agent(state: CareState):
    symptoms = state["symptoms"].lower()

    critical_words = [
        "chest pain",
        "heart attack",
        "unconscious",
        "difficulty breathing",
        "severe bleeding"
    ]

    if any(word in symptoms for word in critical_words):
        urgency = "CRITICAL"
    else:
        urgency = "MODERATE"

    return {"urgency": urgency}


def triage_agent(state: CareState):

    if state["urgency"] == "CRITICAL":
        recommendation = (
            "EMERGENCY: Seek immediate emergency medical care."
        )
    else:
        recommendation = (
            "Please consult a healthcare professional."
        )

    return {"recommendation": recommendation}


def create_care_graph():

    workflow = StateGraph(CareState)

    workflow.add_node("symptom_analysis", symptom_agent)
    workflow.add_node("triage", triage_agent)

    workflow.set_entry_point("symptom_analysis")

    workflow.add_edge("symptom_analysis", "triage")
    workflow.add_edge("triage", END)

    return workflow.compile()


care_graph = create_care_graph()