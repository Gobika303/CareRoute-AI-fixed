"""
recommendation_agent.py - Multi-criteria ranking and recommendation agent
"""
from typing import List, Tuple, Optional
from models.schemas import Hospital, IntentResult

class RecommendationAgent:
    def rank_hospitals(
        self,
        candidates: List[Hospital],
        intent: IntentResult
    ) -> Tuple[Optional[Hospital], List[Hospital], List[str]]:
        if not candidates:
            return None, [], ["No candidate hospitals found in range."]

        reasoning_logs: List[str] = []
        specialty = intent.specialty_needed.lower()

        scored_hospitals: List[Tuple[float, Hospital]] = []

        for h in candidates:
            # 1. Proximity score (closer = higher score, max 40 pts)
            prox_score = max(0.0, 40.0 - (h.distance_km * 4.0))

            # 2. Bed availability score (max 25 pts)
            bed_score = min(25.0, h.icu_beds_available * 1.5)

            # 3. Rating score (max 15 pts)
            rating_score = (h.rating / 5.0) * 15.0

            # 4. Specialty alignment score (max 20 pts)
            spec_match = any(specialty in s.lower() for s in h.specialties)
            spec_score = 20.0 if spec_match else 5.0

            total_score = prox_score + bed_score + rating_score + spec_score
            scored_hospitals.append((total_score, h))

        # Sort descending by composite score
        scored_hospitals.sort(key=lambda x: x[0], reverse=True)

        primary = scored_hospitals[0][1]
        alternatives = [x[1] for x in scored_hospitals[1:4]]

        reasoning_logs.append(
            f"Evaluated {len(candidates)} candidate facilities for specialty '{intent.specialty_needed}'."
        )
        reasoning_logs.append(
            f"Selected '{primary.name}' as primary recommendation (ETA: {primary.eta_mins}m, {primary.icu_beds_available} ICU beds, Rating: {primary.rating}/5)."
        )

        return primary, alternatives, reasoning_logs
