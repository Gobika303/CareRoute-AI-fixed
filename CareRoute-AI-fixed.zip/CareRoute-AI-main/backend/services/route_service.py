"""
route_service.py - Routing calculations and step-by-step navigation
"""
import math
from typing import List, Tuple
from models.schemas import RouteDetails

class RouteService:
    def _haversine(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        R = 6371.0
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return round(R * c, 2)

    def calculate_route(
        self,
        origin_lat: float,
        origin_lng: float,
        dest_lat: float,
        dest_lng: float,
        origin_name: str = "Current Location",
        dest_name: str = "Destination Medical Facility"
    ) -> RouteDetails:
        dist_km = max(0.6, self._haversine(origin_lat, origin_lng, dest_lat, dest_lng))
        # Estimate average speed 36 km/h in urban traffic -> ~1.7 mins per km
        eta_mins = max(2, int(round((dist_km / 36.0) * 60)))

        # Interpolate 5 realistic waypoint coordinates for map line display
        coords: List[List[float]] = []
        steps = 5
        for i in range(steps + 1):
            factor = i / float(steps)
            # Add slight curvature for realistic road simulation
            curve = math.sin(factor * math.pi) * 0.003
            lat = origin_lat + factor * (dest_lat - origin_lat) + curve
            lng = origin_lng + factor * (dest_lng - origin_lng) - curve
            coords.append([round(lat, 5), round(lng, 5)])

        instructions = [
            f"Start heading toward main arterial road from {origin_name}.",
            f"Continue for {round(dist_km * 0.3, 1)} km through signal junction.",
            f"Take the right turn onto the Medical Corridor bypass.",
            f"Proceed straight for {round(dist_km * 0.5, 1)} km with green corridor priority.",
            f"Turn left into emergency bay. Arrive at {dest_name} (Emergency Casualty Entrance)."
        ]

        return RouteDetails(
            origin_name=origin_name,
            destination_name=dest_name,
            distance_km=dist_km,
            eta_mins=eta_mins,
            driving_instructions=instructions,
            coordinates=coords
        )
