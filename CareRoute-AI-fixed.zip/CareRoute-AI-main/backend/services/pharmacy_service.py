"""
pharmacy_service.py - Pharmacy data service and emergency stock queries
"""
import math
from typing import List, Optional
from models.schemas import Pharmacy

class PharmacyService:
    def __init__(self):
        self._pharmacies = [
            Pharmacy(
                id="PHARM_01",
                name="Apollo 24/7 Emergency Pharmacy & Oxygen Hub",
                latitude=13.0610,
                longitude=80.2485,
                distance_km=1.2,
                eta_mins=3,
                is_24_hours=True,
                phone="+91 44 2829 1111",
                address="Near Apollo Main Hospital, Greams Rd",
                rating=4.9,
                emergency_stock=["Oxygen Canisters", "Burn Dressing Kits", "Asthma Inhalers", "Insulin", "EpiPens", "IV Fluids"]
            ),
            Pharmacy(
                id="PHARM_02",
                name="MedPlus 24-Hour Medical Depot",
                latitude=13.0780,
                longitude=80.2520,
                distance_km=2.1,
                eta_mins=5,
                is_24_hours=True,
                phone="+91 44 2642 9988",
                address="142 Poonamallee High Rd, Kilpauk",
                rating=4.7,
                emergency_stock=["First Aid Kits", "Nebulizer Solution", "Antibiotics", "Burn Gel", "Blood Pressure Monitors"]
            ),
            Pharmacy(
                id="PHARM_03",
                name="Netmeds Express 24/7 Store",
                latitude=13.0450,
                longitude=80.2330,
                distance_km=3.0,
                eta_mins=8,
                is_24_hours=True,
                phone="+91 44 3000 4000",
                address="Gopathi Narayanaswami Chetty Rd, T. Nagar",
                rating=4.6,
                emergency_stock=["Emergency Contraceptives", "Pain Relief Injections", "Cardiac Emergency Tablets", "Orthopedic Braces"]
            ),
            Pharmacy(
                id="PHARM_04",
                name="Government Medical Relief & Drug Store",
                latitude=13.0830,
                longitude=80.2710,
                distance_km=2.9,
                eta_mins=7,
                is_24_hours=True,
                phone="044 2530 5111",
                address="Near Central Railway Station, Park Town",
                rating=4.5,
                emergency_stock=["Anti-Venom Vials", "Tetanus Toxoid", "Surgical Suture Kits", "Saline Bags", "Burn Ointment"]
            )
        ]

    def _haversine(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        R = 6371.0
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return round(R * c, 2)

    def get_nearby_pharmacies(self, user_lat: Optional[float] = None, user_lng: Optional[float] = None) -> List[Pharmacy]:
        if user_lat is not None and user_lng is not None:
            for p in self._pharmacies:
                dist = self._haversine(user_lat, user_lng, p.latitude, p.longitude)
                p.distance_km = max(0.4, dist)
                p.eta_mins = max(1, int((p.distance_km / 30.0) * 60))
        return sorted(self._pharmacies, key=lambda p: p.distance_km)

    def search_by_medicine(self, medicine_name: str, user_lat: float, user_lng: float) -> List[Pharmacy]:
        pharmacies = self.get_nearby_pharmacies(user_lat, user_lng)
        matches = [p for p in pharmacies if any(medicine_name.lower() in s.lower() for s in p.emergency_stock)]
        return matches if matches else pharmacies
