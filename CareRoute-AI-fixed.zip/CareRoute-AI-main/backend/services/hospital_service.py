"""
hospital_service.py - Hospital data service and queries
"""
import math
from typing import List, Optional
from models.schemas import Hospital

class HospitalService:
    def __init__(self):
        self._hospitals = [
            Hospital(
                id="HOSP_01",
                name="Apollo Speciality & Level-1 Trauma Hospital",
                type="Multispeciality Hospital",
                latitude=13.0604,
                longitude=80.2496,
                distance_km=1.4,
                eta_mins=4,
                trauma_level="Level 1 Comprehensive Trauma",
                icu_beds_available=16,
                burn_unit=True,
                phone="+91 44 2829 0200",
                address="21 Greams Lane, Thousand Lights",
                rating=4.8,
                specialties=["Cardiology", "Trauma & Emergency", "Neurology", "Burn Care", "Pulmonology"]
            ),
            Hospital(
                id="HOSP_02",
                name="Government General Hospital (RGGGH)",
                type="Tertiary Government Hospital",
                latitude=13.0827,
                longitude=80.2707,
                distance_km=2.8,
                eta_mins=7,
                trauma_level="Tertiary Trauma & Disaster Center",
                icu_beds_available=28,
                burn_unit=True,
                phone="108 / +91 44 2530 5000",
                address="EVR Periyar Salai, Park Town",
                rating=4.5,
                specialties=["General Medicine", "Trauma & Emergency", "Burn Care", "Toxicology", "Surgery"]
            ),
            Hospital(
                id="HOSP_03",
                name="Fortis Malar Emergency & Heart Institute",
                type="Speciality Heart Center",
                latitude=13.0067,
                longitude=80.2575,
                distance_km=4.2,
                eta_mins=11,
                trauma_level="Level 2 Trauma Center",
                icu_beds_available=10,
                burn_unit=False,
                phone="+91 44 4289 2222",
                address="52 1st Main Rd, Gandhi Nagar, Adyar",
                rating=4.7,
                specialties=["Cardiology", "Cardiac ICU", "Vascular Surgery", "Pulmonology"]
            ),
            Hospital(
                id="HOSP_04",
                name="MIOT International Orthopedics & Trauma",
                type="Trauma Center",
                latitude=13.0243,
                longitude=80.1793,
                distance_km=5.6,
                eta_mins=14,
                trauma_level="Level 1 Orthopedic Trauma",
                icu_beds_available=14,
                burn_unit=False,
                phone="+91 44 4200 2288",
                address="4/112 Mount Poonamallee Rd, Manapakkam",
                rating=4.6,
                specialties=["Orthopedics", "Trauma & Emergency", "Neurosurgery", "Spine Care"]
            ),
            Hospital(
                id="HOSP_05",
                name="Rainbow Children's Hospital & BirthRight",
                type="Pediatric Specialty",
                latitude=13.0428,
                longitude=80.2450,
                distance_km=2.5,
                eta_mins=6,
                trauma_level="Pediatric Emergency Unit",
                icu_beds_available=8,
                burn_unit=False,
                phone="+91 44 4012 2000",
                address="15 Rajiv Gandhi Salai, Guindy",
                rating=4.9,
                specialties=["Pediatrics", "Neonatal ICU", "Pediatric Surgery", "Child Allergy"]
            ),
            Hospital(
                id="HOSP_06",
                name="LifeLine Urgent Care Clinic & Day Care",
                type="Urgent Care Clinic",
                latitude=13.0760,
                longitude=80.2400,
                distance_km=1.1,
                eta_mins=3,
                trauma_level="Primary Urgent Triage",
                icu_beds_available=4,
                burn_unit=False,
                phone="+91 98401 23456",
                address="88 Taylor's Road, Kilpauk",
                rating=4.4,
                specialties=["General Medicine", "First Aid", "Fever Clinic", "Minor Trauma"]
            )
        ]

    def _haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        R = 6371.0  # Earth radius in km
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return round(R * c, 2)

    def get_all_hospitals(self, user_lat: Optional[float] = None, user_lng: Optional[float] = None) -> List[Hospital]:
        if user_lat is not None and user_lng is not None:
            for h in self._hospitals:
                dist = self._haversine_distance(user_lat, user_lng, h.latitude, h.longitude)
                h.distance_km = max(0.5, dist)
                h.eta_mins = max(2, int((h.distance_km / 35.0) * 60))
        return sorted(self._hospitals, key=lambda h: h.distance_km)

    def get_hospital_by_id(self, hosp_id: str) -> Optional[Hospital]:
        return next((h for h in self._hospitals if h.id == hosp_id), None)

    def find_best_trauma_center(self, user_lat: float, user_lng: float, requires_burn: bool = False) -> Hospital:
        hospitals = self.get_all_hospitals(user_lat, user_lng)
        candidates = [h for h in hospitals if "Trauma" in h.trauma_level or "Emergency" in h.specialties]
        if requires_burn:
            burn_cand = [h for h in candidates if h.burn_unit]
            if burn_cand:
                candidates = burn_cand
        
        # Rank by travel time and ICU capacity
        ranked = sorted(candidates, key=lambda h: (h.eta_mins, -h.icu_beds_available))
        return ranked[0] if ranked else hospitals[0]

    def filter_by_specialty(self, specialty: str, user_lat: float, user_lng: float) -> List[Hospital]:
        hospitals = self.get_all_hospitals(user_lat, user_lng)
        matches = [h for h in hospitals if any(specialty.lower() in s.lower() for s in h.specialties)]
        return matches if matches else hospitals
