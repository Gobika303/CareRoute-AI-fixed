"""
maps_tool.py - Tool for geospatial routing and map polyline generation
"""
from typing import Dict, Any
from services.route_service import RouteService
from models.schemas import RouteDetails

class MapsTool:
    def __init__(self, route_service: RouteService):
        self.route_service = route_service

    def get_route(
        self,
        origin_lat: float,
        origin_lng: float,
        dest_lat: float,
        dest_lng: float,
        origin_name: str,
        dest_name: str
    ) -> RouteDetails:
        """Calculates distance, ETA, and turn-by-turn guidance between two points."""
        return self.route_service.calculate_route(
            origin_lat, origin_lng, dest_lat, dest_lng, origin_name, dest_name
        )
