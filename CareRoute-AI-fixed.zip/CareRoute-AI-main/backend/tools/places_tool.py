"""
places_tool.py - Tool for finding nearby medical places and pharmacies
"""
from typing import List, Optional
from services.hospital_service import HospitalService
from services.pharmacy_service import PharmacyService
from models.schemas import Hospital, Pharmacy

class PlacesTool:
    def __init__(self, hospital_service: HospitalService, pharmacy_service: PharmacyService):
        self.hospital_service = hospital_service
        self.pharmacy_service = pharmacy_service

    def find_nearby_hospitals(
        self,
        lat: float,
        lng: float,
        specialty: Optional[str] = None
    ) -> List[Hospital]:
        if specialty:
            return self.hospital_service.filter_by_specialty(specialty, lat, lng)
        return self.hospital_service.get_all_hospitals(lat, lng)

    def find_nearby_pharmacies(
        self,
        lat: float,
        lng: float,
        medicine: Optional[str] = None
    ) -> List[Pharmacy]:
        if medicine:
            return self.pharmacy_service.search_by_medicine(medicine, lat, lng)
        return self.pharmacy_service.get_nearby_pharmacies(lat, lng)
