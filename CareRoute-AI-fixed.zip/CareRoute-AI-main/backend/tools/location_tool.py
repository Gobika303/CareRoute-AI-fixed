"""
location_tool.py - Geocoding and location resolution tool
"""
from typing import Tuple, Dict
from config.settings import Config

class LocationTool:
    LANDMARKS: Dict[str, Tuple[float, float]] = {
        "anna nagar": (13.0850, 80.2100),
        "t. nagar": (13.0418, 80.2341),
        "t nagar": (13.0418, 80.2341),
        "guindy": (13.0067, 80.2025),
        "adyar": (13.0012, 80.2565),
        "kilpauk": (13.0800, 80.2400),
        "thousand lights": (13.0604, 80.2496),
        "park town": (13.0827, 80.2707),
        "velachery": (12.9800, 80.2200),
        "mylapore": (13.0333, 80.2667)
    }

    def resolve_location(self, text: str, user_lat: float = None, user_lng: float = None) -> Tuple[float, float, str]:
        """Resolves latitude and longitude from text mention or GPS coordinates."""
        if user_lat is not None and user_lng is not None:
            return user_lat, user_lng, "Current GPS Location"

        text_lower = text.lower()
        for landmark, coords in self.LANDMARKS.items():
            if landmark in text_lower:
                return coords[0], coords[1], landmark.title()

        return Config.DEFAULT_LATITUDE, Config.DEFAULT_LONGITUDE, Config.DEFAULT_CITY + " Central"
