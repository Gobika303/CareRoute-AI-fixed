# CareRoute AI

CareRoute AI is a local demonstration of a React/Vite frontend and FastAPI backend with a deterministic multi-agent workflow.

## Requirements
- Python 3.11 or 3.12 recommended
- Node.js LTS (includes npm)
- Internet access for first-time package installation

## Quick start on Windows
1. Extract the ZIP to a normal writable folder (do not run it from inside the ZIP).
2. Install Python and Node.js LTS if not already installed.
3. Double-click `start.bat`. It installs dependencies and opens separate backend and frontend terminals.
4. Open `http://localhost:3000`.
5. API health: `http://127.0.0.1:8000/`; API docs: `http://127.0.0.1:8000/docs`.

## Manual start
Open two terminals from the project root.

Backend terminal:
```powershell
cd backend
python -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Frontend terminal:
```powershell
cd frontend
npm install
npm run dev -- --host 127.0.0.1
```

## Troubleshooting
- If `node` or `npm` is not recognized, install Node.js LTS and restart VS Code/PowerShell.
- If port 8000 is already occupied, stop the previous backend terminal with Ctrl+C before starting again.
- If packages fail to install, verify internet access and run the install command again.
- The frontend API base URL is in `frontend/.env`. It should be `http://127.0.0.1:8000/api`.

## Important safety and data note
This is a software demonstration, not a medical device or emergency dispatch service. Hospital/pharmacy listings, phone details, stock/bed availability, ETAs, routes, and dispatch records are static/simulated and are not live-verified. Do not use this application to make real emergency or treatment decisions. In an emergency in India, call 112 or the appropriate local emergency service directly.
