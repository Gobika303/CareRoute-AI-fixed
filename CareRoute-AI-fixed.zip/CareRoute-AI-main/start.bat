@echo off
setlocal
title CareRoute AI Launcher
cd /d "%~dp0"

echo ============================================================
echo CareRoute AI - local development launcher
echo NOTE: Facility details, route estimates, and SOS dispatch are demo data.
echo       This app does NOT contact emergency services.
echo ============================================================
echo.

if not exist "backend\requirements.txt" (
  echo ERROR: backend\requirements.txt was not found.
  pause
  exit /b 1
)
if not exist "frontend\package.json" (
  echo ERROR: frontend\package.json was not found.
  pause
  exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python was not found. Install Python 3.11 or 3.12 and enable Add to PATH.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js/npm was not found. Install Node.js LTS, then reopen this file.
  pause
  exit /b 1
)

if not exist "backend\venv\Scripts\python.exe" (
  if not exist "venv\Scripts\python.exe" (
    echo Creating backend virtual environment...
    python -m venv backend\venv
    if errorlevel 1 goto :error
  )
)

if exist "backend\venv\Scripts\python.exe" (
  set "PYTHON_EXE=%~dp0backend\venv\Scripts\python.exe"
) else (
  set "PYTHON_EXE=%~dp0venv\Scripts\python.exe"
)

echo Installing/checking backend packages...
"%PYTHON_EXE%" -m pip install --upgrade pip
if errorlevel 1 goto :error
"%PYTHON_EXE%" -m pip install -r "%~dp0backend\requirements.txt"
if errorlevel 1 goto :error

echo Installing/checking frontend packages...
cd /d "%~dp0frontend"
call npm install
if errorlevel 1 goto :error

echo Starting backend at http://127.0.0.1:8000 ...
start "CareRoute AI Backend" cmd /k "cd /d ""%~dp0backend"" && ""%PYTHON_EXE%"" -m uvicorn main:app --reload --host 127.0.0.1 --port 8000"

timeout /t 2 /nobreak >nul
echo Starting frontend at http://localhost:3000 ...
start "CareRoute AI Frontend" cmd /k "cd /d ""%~dp0frontend"" && npm run dev -- --host 127.0.0.1"

echo.
echo Started in separate terminal windows.
echo Frontend: http://localhost:3000
echo Backend:  http://127.0.0.1:8000
echo API docs: http://127.0.0.1:8000/docs
echo.
pause
exit /b 0

:error
echo.
echo ERROR: Setup failed. Read the error message above and check Python/Node installation or internet connection.
pause
exit /b 1
