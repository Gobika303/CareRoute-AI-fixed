# CareRoute AI Frontend

## Run
From this directory:
```powershell
npm install
npm run dev
```
Open the local URL printed by Vite (normally `http://localhost:3000`).

The frontend uses `VITE_API_BASE_URL` from `.env`, set to `http://127.0.0.1:8000/api`. Start the FastAPI backend separately; see the root README.

Facility data and emergency dispatch are simulated and are not connected to live services.
