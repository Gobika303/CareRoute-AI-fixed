import React from 'react';

export default function Emergency({ dispatchData, onNavigateRoute, onBack }) {
  if (!dispatchData) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem' }}>
        <h2>No Active Emergency Dispatch</h2>
        <button className="btn btn-primary" onClick={onBack} style={{ marginTop: '1rem' }}>
          Back to Home
        </button>
      </div>
    );
  }

  const { dispatch_id, target_hospital, first_aid_instructions, timestamp, patient_triage } = dispatchData;

  return (
    <div>
      <div style={{ background: 'linear-gradient(90deg, #b91c1c 0%, #ef4444 100%)', color: 'white', padding: '1.5rem', borderRadius: '12px', marginBottom: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <span style={{ background: 'white', color: '#dc2626', padding: '0.25rem 0.6rem', borderRadius: '4px', fontWeight: 800, fontSize: '0.8rem' }}>
            DEMO EMERGENCY SUMMARY
          </span>
          <h2 style={{ fontSize: '1.6rem', fontWeight: 800, marginTop: '0.4rem' }}>
            Demo Emergency Guidance
          </h2>
          <p style={{ fontSize: '0.9rem', opacity: 0.9 }}>
            Dispatch ID: <strong>{dispatch_id}</strong> · {timestamp}
          </p>
        </div>
        <div>
          <a href="tel:108" className="btn btn-outline" style={{ background: 'white', color: '#b91c1c', fontWeight: 800 }}>
            📞 Call Emergency Services (108)
          </a>
        </div>
      </div>

      <div style={{ background: '#3f1d1d', border: '1px solid #ef4444', color: '#fecaca', padding: '0.8rem 1rem', borderRadius: '8px', marginBottom: '1rem' }}>
        Demo only: this application does not dispatch an ambulance or notify a hospital. Facility availability and travel times are not live-verified. For a real emergency in India, call 112 or 108 directly.
      </div>

      <div className="grid-2">
        {/* Hospital Destination */}
        <div className="card" style={{ borderColor: '#ef4444' }}>
          <h3>Target Trauma Center</h3>
          <h2 style={{ color: '#60a5fa', margin: '0.3rem 0' }}>{target_hospital.name}</h2>
          <p style={{ color: '#94a3b8', fontSize: '0.85rem' }}>📍 {target_hospital.address}</p>

          <div style={{ display: 'flex', gap: '1rem', margin: '1rem 0' }}>
            <div style={{ background: '#0b1120', padding: '0.75rem', borderRadius: '8px', flex: 1, textAlign: 'center' }}>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'block' }}>ESTIMATED ETA (DEMO)</span>
              <strong style={{ fontSize: '1.4rem', color: '#10b981' }}>~{target_hospital.eta_mins} mins</strong>
            </div>
            <div style={{ background: '#0b1120', padding: '0.75rem', borderRadius: '8px', flex: 1, textAlign: 'center' }}>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'block' }}>ICU BEDS (DEMO DATA)</span>
              <strong style={{ fontSize: '1.4rem', color: '#38bdf8' }}>{target_hospital.icu_beds_available}</strong>
            </div>
          </div>

          <div className="card-footer">
            <button className="btn btn-primary btn-block" onClick={() => onNavigateRoute(target_hospital)}>
              🧭 View Live Ambulance Corridor Map
            </button>
          </div>
        </div>

        {/* Immediate First Aid Actions */}
        <div className="card">
          <h3 style={{ color: '#f59e0b' }}>⚠️ Immediate Life-Saving First Aid Actions</h3>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>
            These general first-aid suggestions are not a substitute for emergency services:
          </p>

          <ol style={{ paddingLeft: '1.25rem', marginTop: '0.5rem', display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.9rem' }}>
            {(first_aid_instructions || []).map((step, idx) => (
              <li key={idx}><strong>{step}</strong></li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
}
