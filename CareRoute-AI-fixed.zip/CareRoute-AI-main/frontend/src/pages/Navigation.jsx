import React from 'react';
import MapView from '../components/MapView';

export default function Navigation({ route, destination, onBack }) {
  if (!destination) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem' }}>
        <h2>No Destination Selected</h2>
        <button className="btn btn-primary" onClick={onBack} style={{ marginTop: '1rem' }}>
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
        <button className="btn btn-outline btn-sm" onClick={onBack}>
          ← Back
        </button>
        <span style={{ fontSize: '0.85rem', color: '#94a3b8' }}>
          Destination: <strong>{destination.name}</strong>
        </span>
      </div>

      <MapView route={route} destination={destination} />

      <div style={{ marginTop: '1.5rem', display: 'flex', gap: '1rem', justifyContent: 'center' }}>
        <a 
          href={`https://www.google.com/maps/dir/?api=1&destination=${destination.latitude},${destination.longitude}`}
          target="_blank"
          rel="noreferrer"
          className="btn btn-primary"
        >
          🌐 Open in Google Maps
        </a>
        <a href={`tel:${destination.phone}`} className="btn btn-outline">
          📞 Call Reception Desk
        </a>
      </div>
    </div>
  );
}
