import React from 'react';
import SearchBox from '../components/SearchBox';
import ServiceCard from '../components/ServiceCard';
import LocationButton from '../components/LocationButton';
import EmergencyButton from '../components/EmergencyButton';

export default function Home({ onSearch, onTriggerEmergency, location, detectLocation, onQuickCategory }) {
  return (
    <div>
      <section className="hero-section">
        <div style={{ display: 'inline-block', marginBottom: '1rem' }}>
          <LocationButton location={location} onDetect={detectLocation} />
        </div>

        <h1 className="hero-title">
          Smart Care &amp; Emergency Navigation Powered by AI
        </h1>
        <p className="hero-subtitle">
          Describe your symptoms, and our autonomous multi-agent system routes you to the nearest, best-equipped hospital, trauma center, or 24/7 pharmacy in seconds.
        </p>

        <SearchBox onSearch={onSearch} loading={false} />

        <div style={{ marginTop: '2rem' }}>
          <EmergencyButton onTrigger={onTriggerEmergency} />
        </div>
      </section>

      <section style={{ marginTop: '2.5rem' }}>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '1rem', textAlign: 'center' }}>
          Quick Healthcare Categories
        </h2>

        <div className="grid-3">
          <ServiceCard
            icon="🏥"
            title="Level-1 Trauma Centers"
            description="Comprehensive critical care, burn units, and 24/7 cardiac ICU beds."
            onClick={() => onQuickCategory('trauma')}
          />
          <ServiceCard
            icon="💊"
            title="24/7 Emergency Pharmacies"
            description="Late-night prescription refills, oxygen cylinders, and emergency medical supplies."
            onClick={() => onQuickCategory('pharmacy')}
          />
          <ServiceCard
            icon="👶"
            title="Pediatric & Children's Care"
            description="Specialized pediatric emergency departments and neonatal intensive care."
            onClick={() => onQuickCategory('pediatrics')}
          />
        </div>
      </section>
    </div>
  );
}
