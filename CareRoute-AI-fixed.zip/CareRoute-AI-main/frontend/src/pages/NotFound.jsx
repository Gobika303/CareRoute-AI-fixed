import React from 'react';

export default function NotFound({ onHome }) {
  return (
    <div style={{ textAlign: 'center', padding: '4rem 1rem' }}>
      <h1 style={{ fontSize: '3rem', color: '#ef4444' }}>404</h1>
      <h2 style={{ marginBottom: '1rem' }}>Page Not Found</h2>
      <p style={{ color: '#94a3b8', marginBottom: '1.5rem' }}>
        The requested healthcare navigation route does not exist.
      </p>
      <button className="btn btn-primary" onClick={onHome}>
        Return to Home
      </button>
    </div>
  );
}
