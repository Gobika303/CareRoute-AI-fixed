import React from 'react';
import RecommendationCard from '../components/RecommendationCard';
import HospitalCard from '../components/HospitalCard';
import PharmacyCard from '../components/PharmacyCard';
import MapView from '../components/MapView';

export default function Results({ recommendation, onNavigateRoute, onBack }) {
  if (!recommendation) return null;

  const { primary_recommendation, alternative_hospitals, nearby_pharmacies, route_details } = recommendation;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
        <button className="btn btn-outline btn-sm" onClick={onBack}>
          ← Back to Search
        </button>
        <span style={{ fontSize: '0.85rem', color: '#94a3b8' }}>
          Inquiry: <strong>"{recommendation.query}"</strong>
        </span>
      </div>

      <RecommendationCard recommendation={recommendation} />

      {route_details && (
        <div style={{ margin: '1.5rem 0' }}>
          <MapView route={route_details} destination={primary_recommendation} />
        </div>
      )}

      <div style={{ marginTop: '2rem' }}>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '1rem' }}>
          ⭐ Primary Recommended Facility
        </h2>
        {primary_recommendation ? (
          <HospitalCard
            hospital={primary_recommendation}
            isPrimary={true}
            onNavigateRoute={onNavigateRoute}
          />
        ) : (
          <p style={{ color: '#94a3b8' }}>No hospital matched criteria.</p>
        )}
      </div>

      {alternative_hospitals && alternative_hospitals.length > 0 && (
        <div style={{ marginTop: '2rem' }}>
          <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>
            Alternative Verified Hospitals
          </h3>
          <div className="grid-2">
            {alternative_hospitals.map((h) => (
              <HospitalCard
                key={h.id}
                hospital={h}
                isPrimary={false}
                onNavigateRoute={onNavigateRoute}
              />
            ))}
          </div>
        </div>
      )}

      {nearby_pharmacies && nearby_pharmacies.length > 0 && (
        <div style={{ marginTop: '2.5rem' }}>
          <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>
            Nearby 24/7 Pharmacies &amp; Medical Supplies
          </h3>
          <div className="grid-2">
            {nearby_pharmacies.map((p) => (
              <PharmacyCard
                key={p.id}
                pharmacy={p}
                onNavigateRoute={onNavigateRoute}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
