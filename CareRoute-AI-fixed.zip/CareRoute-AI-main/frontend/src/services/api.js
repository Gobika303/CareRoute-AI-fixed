/**
 * api.js - Backend API client for CareRoute AI
 */

const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';

export const api = {
  async processChat(query, latitude, longitude, medicalNotes = "None") {
    const res = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query,
        latitude,
        longitude,
        medical_notes: medicalNotes
      })
    });
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const payload = await res.json();
        detail = payload.detail || payload.message || detail;
      } catch (_) {}
      throw new Error(`API error (${res.status}): ${detail}`);
    }
    return await res.json();
  },

  async getHospitals(lat, lng, specialty = null) {
    let url = `${API_BASE}/hospitals?`;
    if (lat && lng) url += `lat=${lat}&lng=${lng}&`;
    if (specialty) url += `specialty=${encodeURIComponent(specialty)}`;
    const res = await fetch(url);
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const payload = await res.json();
        detail = payload.detail || payload.message || detail;
      } catch (_) {}
      throw new Error(`API error (${res.status}): ${detail}`);
    }
    return await res.json();
  },

  async getPharmacies(lat, lng, medicine = null) {
    let url = `${API_BASE}/pharmacies?`;
    if (lat && lng) url += `lat=${lat}&lng=${lng}&`;
    if (medicine) url += `medicine=${encodeURIComponent(medicine)}`;
    const res = await fetch(url);
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const payload = await res.json();
        detail = payload.detail || payload.message || detail;
      } catch (_) {}
      throw new Error(`API error (${res.status}): ${detail}`);
    }
    return await res.json();
  },

  async getRoute(originLat, originLng, destLat, destLng, destName) {
    const res = await fetch(`${API_BASE}/route`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        origin_lat: originLat,
        origin_lng: originLng,
        dest_lat: destLat,
        dest_lng: destLng,
        dest_name: destName
      })
    });
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const payload = await res.json();
        detail = payload.detail || payload.message || detail;
      } catch (_) {}
      throw new Error(`API error (${res.status}): ${detail}`);
    }
    return await res.json();
  },

  async triggerEmergencyDispatch(hospitalId, userName = "Citizen", medicalNotes = "Critical") {
    const res = await fetch(`${API_BASE}/emergency/dispatch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hospital_id: hospitalId,
        user_name: userName,
        medical_notes: medicalNotes
      })
    });
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const payload = await res.json();
        detail = payload.detail || payload.message || detail;
      } catch (_) {}
      throw new Error(`API error (${res.status}): ${detail}`);
    }
    return await res.json();
  }
};
