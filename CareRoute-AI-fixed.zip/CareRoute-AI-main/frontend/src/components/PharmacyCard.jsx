import React from 'react';

export default function PharmacyCard({ pharmacy, onNavigateRoute }) {
  if (!pharmacy) return null;

  return (
    <div className="card">
      <div className="card-header">
        <div>
          <h3 className="card-title">{pharmacy.name}</h3>
          <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>📍 {pharmacy.address}</span>
        </div>
        <div style={{ textAlign: 'right' }}>
          <span className="badge badge-green">{pharmacy.distance_km} km</span>
          <div style={{ fontSize: '0.75rem', color: '#34d399', fontWeight: 700, marginTop: '2px' }}>
            ~{pharmacy.eta_mins} mins
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
        {pharmacy.is_24_hours && <span className="badge badge-green">24/7 Open</span>}
        <span className="badge badge-blue">★ {pharmacy.rating}</span>
        <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>📞 {pharmacy.phone}</span>
      </div>

      <div>
        <span style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'block', marginBottom: '0.3rem' }}>
          Verified Emergency Stock:
        </span>
        <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap' }}>
          {(pharmacy.emergency_stock || []).map((item, idx) => (
            <span key={idx} className="pill-tag">{item}</span>
          ))}
        </div>
      </div>

      <div className="card-footer">
        <button className="btn btn-outline btn-sm" onClick={() => onNavigateRoute(pharmacy)}>
          🧭 Directions
        </button>
        <a href={`tel:${pharmacy.phone}`} className="btn btn-outline btn-sm">
          📞 Call Store
        </a>
      </div>
    </div>
  );
}
