import React from 'react';

export default function EmergencyButton({ onTrigger }) {
  return (
    <button 
      className="btn btn-emergency"
      onClick={onTrigger}
      title="Instant 1-Click Code Red Ambulance & Trauma Dispatch"
    >
      🚨 INSTANT SOS EMERGENCY
    </button>
  );
}
