import React from 'react';

export default function MapView({ route, destination }) {
  if (!route) {
    return (
      <div className="map-canvas-container">
        <span style={{ color: '#94a3b8' }}>Select a hospital or pharmacy to preview route map.</span>
      </div>
    );
  }

  const coords = route.coordinates || [];

  return (
    <div className="card" style={{ padding: '1rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
        <div>
          <h4 style={{ fontSize: '1rem' }}>🗺️ Route: {route.origin_name} → {route.destination_name}</h4>
          <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Dynamic Ambulance Corridor View</span>
        </div>
        <div style={{ textAlign: 'right' }}>
          <strong style={{ color: '#10b981' }}>{route.distance_km} km</strong> · <span style={{ color: '#38bdf8' }}>~{route.eta_mins} mins</span>
        </div>
      </div>

      <div style={{ background: '#090d16', border: '1px solid #1e293b', borderRadius: '8px', padding: '1rem' }}>
        <svg viewBox="0 0 500 180" style={{ width: '100%', height: 'auto', display: 'block' }}>
          {/* Background Grid */}
          <line x1="20" y1="90" x2="480" y2="90" stroke="#1e293b" strokeDasharray="4" />
          
          {/* Dynamic Route Line */}
          <path
            d="M 50 120 Q 150 40, 250 100 T 450 60"
            fill="none"
            stroke="#10b981"
            strokeWidth="5"
            strokeLinecap="round"
            strokeDasharray="8 6"
          />

          {/* Origin Marker */}
          <circle cx="50" cy="120" r="10" fill="#2563eb" stroke="#ffffff" strokeWidth="2" />
          <text x="50" y="145" fill="#94a3b8" fontSize="10" textAnchor="middle">You (Start)</text>

          {/* Waypoints */}
          <circle cx="250" cy="100" r="5" fill="#f59e0b" />
          <text x="250" y="85" fill="#94a3b8" fontSize="9" textAnchor="middle">Signal Bypass</text>

          {/* Destination Marker */}
          <circle cx="450" cy="60" r="12" fill="#ef4444" stroke="#ffffff" strokeWidth="2" />
          <text x="450" y="40" fill="#f87171" fontSize="11" fontWeight="bold" textAnchor="middle">🏥 Hospital ER</text>
        </svg>
      </div>

      <div style={{ marginTop: '0.75rem' }}>
        <h5 style={{ fontSize: '0.82rem', color: '#94a3b8', marginBottom: '0.35rem' }}>Driving Navigation Steps:</h5>
        <ol style={{ paddingLeft: '1.25rem', fontSize: '0.8rem', color: '#cbd5e1', display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
          {(route.driving_instructions || []).map((step, idx) => (
            <li key={idx}>{step}</li>
          ))}
        </ol>
      </div>
    </div>
  );
}
