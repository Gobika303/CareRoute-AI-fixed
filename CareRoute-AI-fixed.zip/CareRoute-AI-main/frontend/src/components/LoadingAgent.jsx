import React, { useState, useEffect } from 'react';

export default function LoadingAgent() {
  const steps = [
    "CoordinatorAgent: Routing patient inquiry to specialized sub-agents...",
    "IntentAgent: Parsing clinical symptoms & triage urgency level...",
    "PlacesTool: Querying nearby Level-1 trauma centers & ICU beds...",
    "MapsTool: Calculating dynamic green corridor routes & travel times...",
    "RecommendationAgent: Ranking optimal healthcare facilities..."
  ];

  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % steps.length);
    }, 600);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="agent-thinking-box">
      <div className="spinner"></div>
      <h3 style={{ fontSize: '1.1rem', color: '#60a5fa' }}>Autonomous Multi-Agent Analysis</h3>
      <p style={{ fontSize: '0.85rem', color: '#94a3b8', fontFamily: 'monospace' }}>
        {steps[currentStep]}
      </p>
    </div>
  );
}
