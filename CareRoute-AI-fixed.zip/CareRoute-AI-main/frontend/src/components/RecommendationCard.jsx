import React from 'react';

export default function RecommendationCard({ recommendation }) {
  if (!recommendation) return null;
  const { intent, agent_reasoning_log } = recommendation;

  return (
    <div className="card" style={{ background: '#0b1329', borderColor: intent.is_critical ? '#ef4444' : '#3b82f6' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style={{ fontSize: '1.15rem', color: intent.is_critical ? '#f87171' : '#60a5fa' }}>
          🤖 CareRoute AI Triage Assessment
        </h3>
        <span className={`badge ${intent.is_critical ? 'badge-red' : 'badge-blue'}`}>
          {intent.intent_category.replace('_', ' ')}
        </span>
      </div>

      <p style={{ fontSize: '0.9rem', color: '#e2e8f0', margin: '0.5rem 0' }}>
        <strong>Clinical Summary:</strong> {intent.triage_summary}
      </p>

      <div style={{ background: '#060a14', padding: '0.75rem', borderRadius: '8px', border: '1px solid #1e293b' }}>
        <span style={{ fontSize: '0.75rem', color: '#94a3b8', fontWeight: 600, display: 'block', marginBottom: '0.4rem' }}>
          MULTI-AGENT REASONING LOG:
        </span>
        <ul style={{ listStyle: 'none', paddingLeft: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '0.3rem', fontSize: '0.8rem', fontFamily: 'monospace', color: '#38bdf8' }}>
          {(agent_reasoning_log || []).map((log, idx) => (
            <li key={idx}>→ {log}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
