import React from 'react';

export default function ServiceCard({ title, icon, description, onClick }) {
  return (
    <div className="card" onClick={onClick} style={{ cursor: 'pointer' }}>
      <div style={{ fontSize: '2rem' }}>{icon}</div>
      <h3 className="card-title">{title}</h3>
      <p style={{ fontSize: '0.85rem', color: '#94a3b8' }}>{description}</p>
      <div className="card-footer">
        <span style={{ fontSize: '0.8rem', color: '#3b82f6', fontWeight: 600 }}>Explore →</span>
      </div>
    </div>
  );
}
