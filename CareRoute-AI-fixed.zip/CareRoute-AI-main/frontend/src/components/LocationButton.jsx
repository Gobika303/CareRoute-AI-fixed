import React from 'react';

export default function LocationButton({ location, onDetect }) {
  return (
    <button 
      type="button"
      className="btn btn-outline btn-sm"
      onClick={onDetect}
      disabled={location.loading}
      style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}
    >
      <span>📍</span>
      <span>{location.loading ? 'Detecting GPS...' : location.city}</span>
    </button>
  );
}
