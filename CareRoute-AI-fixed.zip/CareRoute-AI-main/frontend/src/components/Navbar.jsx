import React from 'react';

export default function Navbar({ onNavigate, currentPage }) {
  return (
    <header className="navbar">
      <div className="navbar-inner">
        <div className="nav-brand" onClick={() => onNavigate('home')}>
          <span style={{ fontSize: '1.8rem' }}>🚑</span>
          <div>
            <h1>CareRoute AI</h1>
            <span className="nav-tagline">Autonomous Healthcare & Emergency Routing</span>
          </div>
        </div>

        <div className="nav-actions">
          <button 
            className={`btn btn-sm ${currentPage === 'home' ? 'btn-primary' : 'btn-outline'}`}
            onClick={() => onNavigate('home')}
          >
            Home
          </button>
          <button 
            className={`btn btn-sm ${currentPage === 'emergency' ? 'btn-danger' : 'btn-outline'}`}
            onClick={() => onNavigate('emergency')}
          >
            🚨 SOS Emergency
          </button>
          <a href="tel:108" className="hotline-badge">
            📞 108 Ambulance
          </a>
        </div>
      </div>
    </header>
  );
}
