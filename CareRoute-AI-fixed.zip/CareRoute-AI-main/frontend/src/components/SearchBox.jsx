import React, { useState } from 'react';

export default function SearchBox({ onSearch, loading }) {
  const [input, setInput] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    onSearch(input.trim());
  };

  const sampleQueries = [
    "Severe chest pain and sweating near Anna Nagar",
    "Child with high fever and vomiting",
    "24/7 pharmacy with asthma inhalers and burn kit",
    "Deep bleeding cut on arm needing stitches"
  ];

  return (
    <div style={{ width: '100%', maxWidth: '750px', margin: '0 auto' }}>
      <form onSubmit={handleSubmit} className="search-box-container">
        <span style={{ fontSize: '1.2rem' }}>🔍</span>
        <input
          type="text"
          className="search-input"
          placeholder="Describe symptoms or medical need (e.g., 'Severe chest pain near Guindy')..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={loading}
        />
        <button type="submit" className="btn btn-primary" disabled={loading}>
          {loading ? 'Analyzing...' : 'Find Care'}
        </button>
      </form>

      <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap', marginTop: '0.75rem', justifyContent: 'center' }}>
        <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Try:</span>
        {sampleQueries.map((q, idx) => (
          <button
            key={idx}
            type="button"
            className="pill-tag"
            style={{ cursor: 'pointer', border: 'none', background: '#1e293b', color: '#cbd5e1' }}
            onClick={() => { setInput(q); onSearch(q); }}
          >
            {q.substring(0, 32)}...
          </button>
        ))}
      </div>
    </div>
  );
}
