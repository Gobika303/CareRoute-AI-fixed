import React from 'react';

export default function HospitalCard({ hospital, isPrimary, onNavigateRoute }) {
  if (!hospital) return null;

  return (
    <div className="card" style={{ borderColor: isPrimary ? '#2563eb' : undefined }}>
      <div className="card-header">
        <div>
          <h3 className="card-title">{hospital.name}</h3>
          <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>📍 {hospital.address}</span>
        </div>
        <div style={{ textAlign: 'right' }}>
          <span className="badge badge-blue">{hospital.distance_km} km</span>
          <div style={{ fontSize: '0.75rem', color: '#38bdf8', fontWeight: 700, marginTop: '2px' }}>
            ~{hospital.eta_mins} mins
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
        <span className="badge badge-green">★ {hospital.rating}</span>
        <span className="badge badge-blue">{hospital.trauma_level}</span>
        {hospital.burn_unit && <span className="badge badge-red">Burn Unit Ready</span>}
      </div>

      <div style={{ fontSize: '0.82rem', color: '#cbd5e1', display: 'flex', justifyContent: 'space-between', background: '#0b1120', padding: '0.5rem 0.75rem', borderRadius: '6px' }}>
        <span>Available ICU Beds: <strong>{hospital.icu_beds_available}</strong></span>
        <span>Call: <strong>{hospital.phone}</strong></span>
      </div>

      <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap' }}>
        {(hospital.specialties || []).map((s, idx) => (
          <span key={idx} className="pill-tag">{s}</span>
        ))}
      </div>

      <div className="card-footer">
        <button className="btn btn-primary btn-sm" onClick={() => onNavigateRoute(hospital)}>
          🧭 Navigate Route
        </button>
        <a href={`tel:${hospital.phone}`} className="btn btn-outline btn-sm">
          📞 Call Desk
        </a>
      </div>
    </div>
  );
}
