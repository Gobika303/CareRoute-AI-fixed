import React, { useState } from 'react';
import Navbar from './components/Navbar';
import LoadingAgent from './components/LoadingAgent';
import Home from './pages/Home';
import Results from './pages/Results';
import Emergency from './pages/Emergency';
import Navigation from './pages/Navigation';
import NotFound from './pages/NotFound';
import { useLocation } from './hooks/useLocation';
import { api } from './services/api';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState(null);
  const [emergencyDispatch, setEmergencyDispatch] = useState(null);
  const [activeRoute, setActiveRoute] = useState(null);
  const [activeDestination, setActiveDestination] = useState(null);
  const [error, setError] = useState(null);

  const { location, detectLocation } = useLocation();

  const handleSearch = async (queryText) => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.processChat(
        queryText,
        location.latitude,
        location.longitude
      );
      setRecommendation(result);

      if (result.intent && result.intent.is_critical && result.emergency_dispatch) {
        setEmergencyDispatch(result.emergency_dispatch);
        setCurrentPage('emergency');
      } else {
        setCurrentPage('results');
      }
    } catch (err) {
      console.error(err);
      setError('Could not reach CareRoute AI backend. Please verify that the Python server is running.');
    } finally {
      setLoading(false);
    }
  };

  const handleTriggerEmergency = async () => {
    setLoading(true);
    setError(null);
    try {
      const dispatch = await api.triggerEmergencyDispatch('HOSP_01', 'Direct User SOS', 'Immediate Code Red');
      setEmergencyDispatch(dispatch);
      setCurrentPage('emergency');
    } catch (err) {
      console.error(err);
      setError('Failed to trigger emergency dispatch.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickCategory = (category) => {
    let q = '';
    if (category === 'trauma') q = 'Nearest level 1 trauma hospital with ICU beds';
    if (category === 'pharmacy') q = '24/7 open pharmacy with oxygen and burn medicine';
    if (category === 'pediatrics') q = 'Pediatric doctor and emergency child care';
    handleSearch(q);
  };

  const handleNavigateRoute = async (destination) => {
    try {
      setLoading(true);
      const route = await api.getRoute(
        location.latitude,
        location.longitude,
        destination.latitude,
        destination.longitude,
        destination.name
      );
      setActiveRoute(route);
      setActiveDestination(destination);
      setCurrentPage('navigation');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      <Navbar onNavigate={setCurrentPage} currentPage={currentPage} />

      <main className="main-content">
        {error && (
          <div style={{ background: 'rgba(239, 68, 68, 0.15)', border: '1px solid #ef4444', color: '#f87171', padding: '0.75rem 1rem', borderRadius: '8px', marginBottom: '1rem' }}>
            {error}
          </div>
        )}

        {loading && <LoadingAgent />}

        {!loading && currentPage === 'home' && (
          <Home
            onSearch={handleSearch}
            onTriggerEmergency={handleTriggerEmergency}
            location={location}
            detectLocation={detectLocation}
            onQuickCategory={handleQuickCategory}
          />
        )}

        {!loading && currentPage === 'results' && (
          <Results
            recommendation={recommendation}
            onNavigateRoute={handleNavigateRoute}
            onBack={() => setCurrentPage('home')}
          />
        )}

        {!loading && currentPage === 'emergency' && (
          <Emergency
            dispatchData={emergencyDispatch}
            onNavigateRoute={handleNavigateRoute}
            onBack={() => setCurrentPage('home')}
          />
        )}

        {!loading && currentPage === 'navigation' && (
          <Navigation
            route={activeRoute}
            destination={activeDestination}
            onBack={() => setCurrentPage(recommendation ? 'results' : 'home')}
          />
        )}

        {!loading && !['home', 'results', 'emergency', 'navigation'].includes(currentPage) && (
          <NotFound onHome={() => setCurrentPage('home')} />
        )}
      </main>

      <footer style={{ textAlign: 'center', padding: '1.5rem', borderTop: '1px solid #1e293b', fontSize: '0.8rem', color: '#94a3b8' }}>
        <p>CareRoute AI · Autonomous Multi-Agent Healthcare &amp; Emergency Navigation System · B.Tech IT</p>
      </footer>
    </div>
  );
}
