/**
 * useLocation.js - Custom hook to manage GPS location
 */
import { useState, useEffect } from 'react';

export function useLocation() {
  const [location, setLocation] = useState({
    latitude: 13.0827,
    longitude: 80.2707,
    city: 'Chennai Central',
    loading: false,
    error: null
  });

  const detectLocation = () => {
    if (!navigator.geolocation) {
      setLocation(prev => ({ ...prev, error: 'Geolocation not supported by browser.' }));
      return;
    }

    setLocation(prev => ({ ...prev, loading: true, error: null }));

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          city: 'My GPS Location',
          loading: false,
          error: null
        });
      },
      (err) => {
        setLocation(prev => ({
          ...prev,
          loading: false,
          error: 'Using default city location (GPS permission denied).'
        }));
      },
      { timeout: 8000 }
    );
  };

  return { location, detectLocation, setLocation };
}
