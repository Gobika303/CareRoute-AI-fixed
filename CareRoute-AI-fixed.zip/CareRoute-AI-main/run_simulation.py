"""
run_simulation.py - Autonomous Multi-Agent Test Suite for CareRoute AI
Demonstrates symptom triage, emergency dispatch, multi-criteria ranking, and routing.
"""
import sys
import os

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

# Add backend directory to sys.path
project_root = os.path.dirname(os.path.abspath(__file__))
backend_dir = os.path.join(project_root, "backend")
sys.path.insert(0, backend_dir)

from models.schemas import UserQuery
from services.hospital_service import HospitalService
from services.pharmacy_service import PharmacyService
from services.route_service import RouteService
from tools.maps_tool import MapsTool
from tools.places_tool import PlacesTool
from tools.location_tool import LocationTool
from agents.intent_agent import IntentAgent
from agents.emergency_agent import EmergencyAgent
from agents.recommendation_agent import RecommendationAgent
from agents.coordinator_agent import CoordinatorAgent

def run_tests():
    print("=" * 70)
    print(" [*] RUNNING CAREROUTE AI MULTI-AGENT VERIFICATION TEST SUITE")
    print("=" * 70)

    hospital_service = HospitalService()
    pharmacy_service = PharmacyService()
    route_service = RouteService()

    maps_tool = MapsTool(route_service=route_service)
    places_tool = PlacesTool(hospital_service=hospital_service, pharmacy_service=pharmacy_service)
    location_tool = LocationTool()

    intent_agent = IntentAgent()
    emergency_agent = EmergencyAgent()
    recommendation_agent = RecommendationAgent()

    coordinator = CoordinatorAgent(
        intent_agent=intent_agent,
        emergency_agent=emergency_agent,
        recommendation_agent=recommendation_agent,
        maps_tool=maps_tool,
        places_tool=places_tool,
        location_tool=location_tool
    )

    print("\n[TEST 1] Critical Cardiac Emergency Triage & Golden-Hour Pre-Alert")
    q1 = UserQuery("Severe chest pain radiating to left arm near Anna Nagar", user_name="Devanathan", blood_group="A+")
    res1 = coordinator.process_query(q1)

    print(f" -> Intent Category: {res1.intent.intent_category}")
    print(f" -> Urgency Level: {res1.intent.urgency_level}/5 (Is Critical: {res1.intent.is_critical})")
    print(f" -> Recommended Hospital: {res1.primary_recommendation.name}")
    print(f" -> Distance: {res1.primary_recommendation.distance_km} km | ETA: ~{res1.primary_recommendation.eta_mins} mins")
    assert res1.intent.is_critical is True, "Expected critical emergency for chest pain!"
    assert res1.emergency_dispatch is not None, "Expected emergency dispatch packet!"
    print(f" -> Emergency Dispatch ID: {res1.emergency_dispatch.dispatch_id}")
    print(f" -> First-Aid Guidelines Count: {len(res1.emergency_dispatch.first_aid_instructions)}")
    print(" [OK] Critical Cardiac Emergency triage passed!")

    print("\n[TEST 2] Pediatric Consultation Query & Multi-Criteria Ranking")
    q2 = UserQuery("Child with persistent high fever and mild cough near Adyar")
    res2 = coordinator.process_query(q2)

    print(f" -> Specialty Detected: {res2.intent.specialty_needed}")
    print(f" -> Is Critical: {res2.intent.is_critical}")
    print(f" -> Primary Hospital: {res2.primary_recommendation.name}")
    print(f" -> Alternatives Count: {len(res2.alternative_hospitals)}")
    assert "Pediatric" in res2.intent.specialty_needed, "Expected Pediatric specialty!"
    print(" [OK] Pediatric consultation ranking passed!")

    print("\n[TEST 3] Late-Night 24/7 Pharmacy & Emergency Medical Supplies")
    q3 = UserQuery("Need 24/7 open pharmacy with asthma inhaler and burn kit near Kilpauk")
    res3 = coordinator.process_query(q3)

    print(f" -> Intent: {res3.intent.intent_category}")
    print(f" -> Pharmacies Found: {len(res3.nearby_pharmacies)}")
    for p in res3.nearby_pharmacies[:2]:
        print(f"    - {p.name} ({p.distance_km} km, 24-Hours: {p.is_24_hours})")
    assert len(res3.nearby_pharmacies) > 0, "Expected pharmacies to be found!"
    print(" [OK] 24/7 Pharmacy stock query passed!")

    print("\n[TEST 4] Turn-by-Turn Dynamic Driving Route Calculation")
    assert res1.route_details is not None, "Expected route details in recommendation!"
    print(f" -> Route Origin: {res1.route_details.origin_name}")
    print(f" -> Destination: {res1.route_details.destination_name}")
    print(f" -> Distance: {res1.route_details.distance_km} km")
    print(f" -> ETA: {res1.route_details.eta_mins} mins")
    print(f" -> Waypoints Polyline Points: {len(res1.route_details.coordinates)}")
    print(" [OK] Route calculation passed!")

    print("\n" + "=" * 70)
    print(" [SUCCESS] ALL CAREROUTE AI MULTI-AGENT VERIFICATIONS PASSED!")
    print("=" * 70)

if __name__ == "__main__":
    run_tests()
